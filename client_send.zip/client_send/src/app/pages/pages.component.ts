import { Component, OnInit, ViewChild,HostListener, ViewChildren,ComponentFactoryResolver, QueryList,Inject,ViewContainerRef, ComponentFactory, ComponentRef } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';
import { AppSettings } from '../app.settings';
import { Settings } from '../app.settings.model';
import { MenuService } from '../theme/components/menu/menu.service';
import {BarcodeInfoComponent} from './barcode-info/barcode-info.component';
import { HttpClient, HttpHeaders} from '@angular/common/http';

//for generating pdf
import pdfMake from "pdfmake/build/pdfmake";  
import pdfFonts from "pdfmake/build/vfs_fonts"; 

//for generating barcode
import JsBarcode from 'jsbarcode/bin/JsBarcode'

pdfMake.vfs = pdfFonts.pdfMake.vfs;

@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss'],
  providers: [ MenuService ,HttpClient]
})

export class PagesComponent implements OnInit { 
  @ViewChild('sidenav') sidenav:any;
  @ViewChild('container', { read: ViewContainerRef }) container: ViewContainerRef;

  //Informations of All Barcodes
  barcodeInfos = [
    {
      'pdf_type' : 1,
      'fnsku' : '',
      'product_name' : '',
      'product_count' : ''
    }
  ];

  //index of last barcode information
  lastIndex = 1;

  //Members for controlling UI
  @ViewChildren(PerfectScrollbarDirective) pss: QueryList<PerfectScrollbarDirective>;
  public settings:Settings;
  public menus = ['vertical', 'horizontal'];
  public menuOption:string;
  public menuTypes = ['default', 'compact', 'mini'];
  public menuTypeOption:string;
  public lastScrollTop:number = 0;
  public showBackToTop:boolean = false;
  public toggleSearchBar:boolean = false;

  //member for factorying component dynamtically
  private resolver : ComponentFactoryResolver;

  //constructor
  constructor(private factoryResolver: ComponentFactoryResolver,
              public appSettings:AppSettings, 
              public router:Router, 
              private menuService: MenuService,
              private https: HttpClient)
  {        
    this.settings = this.appSettings.settings;
    this.resolver = factoryResolver;
  }

  //predefined barcode informations
  private maxCounts = [0,21,24,24,24,24,24,24,27,30,40,44];
  private barcodeSizes = [[0,0],[180,108],[180,96.0945],[183.118,95.811],[187.087,96.0945],[187.087,99.21],[198.4255,102.047],[198.4255,104.882],[180,83.905],[189,72],[148.819,84.189],[137.48,72]];
  private pageSizes = [[0,0],[597.6,842.4],[597.6,842.4],[597.6,842.4],[597.6,842.4],[597.6,842.4],[597.6,842.4],[597.6,842.4],[597.6,842.4],[612,792],[597.6,842.4],[597.6,842.4]];

  //Barcode Components added dynamatically
  public BCComponents: ComponentRef<BarcodeInfoComponent>[] = [];

  //shifting variable for pdf type selecting
  public pdfType : number = 1;

  //Init Functions
  ngOnInit() {
    if(window.innerWidth <= 768){
      this.settings.menu = 'vertical';
      this.settings.sidenavIsOpened = false;
      this.settings.sidenavIsPinned = false;
    }
    this.menuOption = this.settings.menu; 
    this.menuTypeOption = this.settings.menuType; 
  }
  ngAfterViewInit(){
    setTimeout(() => { this.settings.loadingSpinner = false }, 300);
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) { 
        if(!this.settings.sidenavIsPinned){
          this.sidenav.close(); 
        }      
        if(window.innerWidth <= 768){
          this.sidenav.close(); 
        } 
      }                
    });
    if(this.settings.menu == "vertical")
      this.menuService.expandActiveSubMenu(this.menuService.getVerticalMenuItems());

    setTimeout(() => {
      this.barcodeInfos.forEach(barcodeInfo => {
          this.loadComponent(barcodeInfo);
      });
    });
  }

  //create barcode information component dynamatically
  private loadComponent(barcodeInfo: any): void {
    const componentFactory = this.resolver.resolveComponentFactory(BarcodeInfoComponent);
    const componentRef = this.container.createComponent(componentFactory);
    const inst = (<BarcodeInfoComponent>componentRef.instance);
    inst.barcodeInfo = barcodeInfo;
    inst.componentRef = componentRef;
    this.BCComponents[this.BCComponents.length] = componentRef;
  }

  //this function adds new barcode component dynamatically
  public addNewBarcode()
  {
    const barcodeInfo = {
        'pdf_type': 1,
        'fnsku' : '',
        'product_name' : '',
        'product_count' : '0'
    }
    this.loadComponent(barcodeInfo);
  }

  //this fucntion generates barcode image from text
  textToBase64Barcode(text, product_name){
    var canvas = document.createElement("canvas");
    const barcodeMargin = 35;
    JsBarcode(canvas, text, {format: "CODE128",margin: barcodeMargin,fontSize: 20});
    
    const x = (-canvas.width / 2) + barcodeMargin;
    const y = canvas.height - (barcodeMargin / 2);

    const ctx = canvas.getContext('2d');
    ctx.font = 'bold 20px Monospace';
    ctx.textAlign = 'center';
    ctx.fillStyle = 'black';

    ctx.fillText(product_name, x, y, canvas.width);

    return canvas.toDataURL("image/png");
  }

  //this function generate pdf with all barcodes
  public generatePdf()
  {
    //variable for containing barcode datas
    let content = [];

    //Max Count for placing on a paper
    let maxCountPerPage = this.maxCounts[this.pdfType];

    //barcode width (pixels)
    let barcodeWidth = this.barcodeSizes[this.pdfType][0];

    //barcode height (pixels)
    let barcodeHeight = this.barcodeSizes[this.pdfType][1];

    //page width (pixels)
    let pageWidth = this.pageSizes[this.pdfType][0];

    //page height pixels
    let pageHeight = this.pageSizes[this.pdfType][1];

    //column count for placing barcodes
    let bcColCount =Math.floor(pageWidth / barcodeWidth) ;

    //row count for placing barcodes
    let bcRowCount = Math.floor(maxCountPerPage / bcColCount) < Math.floor(pageHeight / barcodeHeight) ? 
                      Math.floor(maxCountPerPage / bcColCount) : Math.floor(pageHeight / barcodeHeight);

    //breath padding variable
    let paddingWidth = (pageWidth - bcColCount * barcodeWidth) / (bcColCount + 1);

    //height padding varible
    let paddingHeight = (pageHeight - bcRowCount * barcodeHeight) / (bcRowCount + 1);
    let pageMargin = 0;
    
    //index for loop and indexing
    let loop_index = 0;

    //construct barcode images for all barcodes
    this.BCComponents.forEach(bc_component => {

      const inst = (<BarcodeInfoComponent>bc_component.instance);
      let barcodeCount = inst.barcodeInfo.product_count;

      for( let i=0;i<barcodeCount;i++)
      {
        //coordinate of durrent barcode
        let x = (loop_index % bcColCount) * barcodeWidth + paddingWidth * (loop_index % bcColCount + 1);
        let y = paddingHeight + (barcodeHeight + paddingHeight) * (Math.floor(loop_index / bcColCount) % bcRowCount);
        
        //content of one barcode
        content[loop_index] = {
          image: this.textToBase64Barcode(inst.barcodeInfo.fnsku, inst.barcodeInfo.product_name),
          width: barcodeWidth,
          height: barcodeHeight,
          absolutePosition: {
            x:x,
            y:y
          },
          pageBreak: ''
        };

        //page control
        if(loop_index > 0 && loop_index % maxCountPerPage === 0)
        {
          content[loop_index]["pageBreak"] = 'before';
        }
        loop_index++;
      }
    });

    //pdf document infomation
    const documentDefination ={
      pageSize: {width: pageWidth, height: pageHeight},
      pageMargins: [ pageMargin, pageMargin, pageMargin, pageMargin ],
      content: content
      };
      pdfMake.createPdf(documentDefination).download();
  }
}
