import { Component,Input,ComponentRef, OnInit } from '@angular/core';

@Component({
  selector: 'app-barcode-info',
  templateUrl: './barcode-info.component.html',
  styleUrls: ['./barcode-info.component.scss']
})
export class BarcodeInfoComponent implements OnInit {
  barcodeInfo: any;
  componentRef: ComponentRef<BarcodeInfoComponent>;
  constructor() { }

  ngOnInit(): void {
  }
  public remove()
  {
    this.componentRef.destroy();
  }
}
